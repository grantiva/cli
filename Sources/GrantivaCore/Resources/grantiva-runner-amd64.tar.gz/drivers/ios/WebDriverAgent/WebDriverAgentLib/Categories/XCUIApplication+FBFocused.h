/**
 * Copyright (c) 2018-present, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree.
 */

#import <XCTest/XCTest.h>
#import "FBElement.h"

NS_ASSUME_NONNULL_BEGIN

@interface XCUIApplication (FBFocused)

/**
 Return current focused element
 */
- (id<FBElement>)fb_focusedElement;

@end

NS_ASSUME_NONNULL_END
