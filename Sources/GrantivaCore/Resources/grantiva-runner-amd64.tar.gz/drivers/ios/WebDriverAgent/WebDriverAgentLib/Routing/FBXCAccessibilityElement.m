/**
 * Copyright (c) 2015-present, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree.
 */

#import "FBXCAccessibilityElement.h"

#import "FBElementUtils.h"

BOOL FBIsAXElementEqualToOther(id<FBXCAccessibilityElement> first, id<FBXCAccessibilityElement> second)
{
  return nil != second && [[FBElementUtils uidWithAccessibilityElement:first]
          isEqualToString:([FBElementUtils uidWithAccessibilityElement:second] ?: @"")];
}
