/**
 * Copyright (c) 2015-present, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree.
 */

#import "FBNavigationController.h"

@implementation FBNavigationController

#if !TARGET_OS_TV
- (UIInterfaceOrientationMask)supportedInterfaceOrientations
{
  return UIInterfaceOrientationMaskAll;
}
#endif

- (BOOL)shouldAutorotate
{
  return YES;
}

@end
