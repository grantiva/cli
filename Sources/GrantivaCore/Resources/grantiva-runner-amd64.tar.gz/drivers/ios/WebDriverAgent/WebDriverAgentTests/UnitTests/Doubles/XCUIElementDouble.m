/**
 * Copyright (c) 2015-present, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree.
 */

#import "XCUIElementDouble.h"

@interface XCUIElementDouble ()
@property (nonatomic, assign, readwrite) BOOL didResolve;
@property (nonatomic, copy, readwrite, nonnull) NSArray<NSString *> *typedKeys;
@property (nonatomic, assign, readwrite) NSUInteger lastTypedModifierFlags;
@end

@implementation XCUIElementDouble

- (id)init
{
  self = [super init];
  if (self) {
    self.wdFrame = CGRectZero;
    self.wdNativeFrame = CGRectZero;
    self.wdName = @"testName";
    self.wdLabel = @"testLabel";
    self.wdValue = @"magicValue";
    self.wdPlaceholderValue = @"testPlaceholderValue";
    self.wdTraits = @"testTraits";
    self.wdCustomActions = nil;
    self.wdVisible = YES;
    self.wdAccessible = YES;
    self.wdNativeAccessibilityElement = YES;
    self.wdEnabled = YES;
    self.wdSelected = YES;
    self.wdFocused = YES;
    self.wdHittable = YES;
    self.wdIndex = 0;
#if TARGET_OS_TV
    self.wdFocused = YES;
#endif
    self.children = @[];
    self.wdRect =  @{@"x": @0,
                     @"y": @0,
                     @"width": @0,
                     @"height": @0,
                     };
    self.wdAccessibilityContainer = NO;
    self.elementType = XCUIElementTypeOther;
    self.wdType = @"XCUIElementTypeOther";
    self.wdUID = @"0";
    self.lastSnapshot = nil;
    self.typedKeys = @[];
  }
  return self;
}

- (void)typeKey:(NSString *)key modifierFlags:(NSUInteger)modifierFlags
{
  self.typedKeys = [self.typedKeys arrayByAddingObject:key];
  self.lastTypedModifierFlags = modifierFlags;
}

- (id)fb_valueForWDAttributeName:(NSString *)name
{
  return @"test";
}

- (id)query
{
  return nil;
}

- (void)resolve
{
  self.didResolve = YES;
}

- (void)fb_nativeResolve
{
  self.didResolve = YES;
}

- (id _Nonnull)fb_standardSnapshot;
{
  return [self lastSnapshot];
}

- (id _Nonnull)fb_customSnapshot;
{
  return [self lastSnapshot];
}

- (NSString *)fb_cacheId
{
  return self.wdUID;
}

- (id)lastSnapshot
{
  return self;
}

- (id)fb_uid
{
  return self.wdUID;
}

- (NSString *)wdTraits
{
  return self.wdTraits;
}

@end
